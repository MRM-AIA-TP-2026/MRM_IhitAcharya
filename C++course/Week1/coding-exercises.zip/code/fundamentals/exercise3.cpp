#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  string line1 = (argv[1]);
  string line2 = (argv[2]);
  
  //add code below this line

cout << line1 << '\n';
cout << line2 << '\n';


  //add code above this line
  
  return 0;
  
}
