#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  //add code below this line

cout << "Okay,";
cout << " it is time to learn about operators.";

  //add code above this line
  
  return 0;
  
}
