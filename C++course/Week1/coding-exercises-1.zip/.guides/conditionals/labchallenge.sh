cd code/conditionals
g++ labchallenge.cpp -o labchallenge
./labchallenge $1
