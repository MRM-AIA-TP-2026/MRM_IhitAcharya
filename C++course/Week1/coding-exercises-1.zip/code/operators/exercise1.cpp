#include <iostream>
using namespace std;

int main() {
  
  //fix the code below this line

  int a = 5;
  int b = 6;

  //fix the code above this line
  
  cout << (a * 3 + b - 8 / 2) << endl;
  
  return 0;
  
}
