#include <iostream>
using namespace std;

int main() {
  
  //add code below this line

  cout << boolalpha << ((5 > 7) && (false || 1 < 9) || 4 != 5 && ! (2 >= 3)) << endl;

  //add code above this line
  
  return 0;
  
}
