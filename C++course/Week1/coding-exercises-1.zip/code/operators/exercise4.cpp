#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
double x = 7;
double y = 2;
cout << x/y;


  //add code above this line
  
  return 0;
  
}
