#include <iostream>
using namespace std;

int main() {
  
  //add code below this line
cout << boolalpha << (6 == 5);


  //add code above this line
  
  return 0;
  
}
