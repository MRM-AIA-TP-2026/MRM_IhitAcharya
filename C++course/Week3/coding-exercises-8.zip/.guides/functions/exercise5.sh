cd code/functions
g++ exercise5.cpp -o exercise5
./exercise5 $*
