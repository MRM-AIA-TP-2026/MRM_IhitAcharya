cd code/recursion
g++ exercise1.cpp -o exercise1
./exercise1 $*
