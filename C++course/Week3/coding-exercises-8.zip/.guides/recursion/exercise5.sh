cd code/recursion
g++ exercise5.cpp -o exercise5
./exercise5 $*
