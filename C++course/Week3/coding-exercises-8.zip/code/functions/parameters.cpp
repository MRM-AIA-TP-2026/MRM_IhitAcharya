#include <iostream>
using namespace std;

//add function definitions below this line



//add function definitions above this line
  
int main() {
  Add(5, 7);
  return 0;
}
