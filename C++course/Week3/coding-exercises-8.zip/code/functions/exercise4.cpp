#include <iostream>
#include <vector>
using namespace std;

//add code below this line
bool IsPalindrome(string x)

{int temp = 0;
int len = x.length();
for (int i = 0;i<len/2;i++)
{
  if (x[i]==x[len-i-1])
{temp = 1;
continue;}

else
{temp = 0;
break;}

}

return temp;
}


//add code above this line

int main(int argc, char** argv) {
  string x = argv[1];
  cout << boolalpha << IsPalindrome(x) << endl;
}