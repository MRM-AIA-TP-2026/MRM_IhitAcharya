#include <iostream>
using namespace std;

//add class definitions below this line
class PracticeClass{
public:
string name;
};

  
//add class definitions above this line

int main() {
  
  PracticeClass obj;
  obj.name = "Class Object";
  cout << obj.name;
  
  return 0;
  
}
