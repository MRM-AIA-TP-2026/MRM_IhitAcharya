cd code/mutability
g++ labchallenge.cpp -o labchallenge
./labchallenge $*
