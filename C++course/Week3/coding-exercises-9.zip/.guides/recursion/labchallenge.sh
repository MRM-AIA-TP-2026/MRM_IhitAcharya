cd code/recursion
g++ labchallenge.cpp -o labchallenge
./labchallenge $*
