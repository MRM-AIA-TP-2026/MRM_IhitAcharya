cd code/recursion
g++ exercise3.cpp -o exercise3
./exercise3 $*
