cd code/recursion
g++ exercise2.cpp -o exercise2
./exercise2 $*
