cd code/functions
g++ exercise4.cpp -o exercise4
./exercise4 $*
