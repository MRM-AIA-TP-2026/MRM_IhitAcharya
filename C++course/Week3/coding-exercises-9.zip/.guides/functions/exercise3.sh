cd code/functions
g++ exercise3.cpp -o exercise3
./exercise3 $*
