#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;

//add function definitions below this line
int GetMax(vector<int> x)
{if (x.size()==1)
return x.at(0);
else
{int temp = x.at(0);
int pos;
for (int i = 1;i<x.size();i++)
{if (x.at(i)>temp)
{temp = x.at(i);}
}
return temp;
 
} 
}


//add function definitions above this line

int main(int argc, char** argv) {
  vector<int> nums;
  for (int i = 1; i < argc; i++) {
    nums.push_back(stoi(argv[i]));
  }
  cout << GetMax(nums) << endl;
  return 0;
}
