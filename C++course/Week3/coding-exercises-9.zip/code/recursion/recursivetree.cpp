////////// DO NOT EDIT HEADER! //////////
#include <iostream>                    //
#include "CTurtle.hpp"                 //
#include "CImg.h"                      //
using namespace cturtle;               //
using namespace std;                   //
/////////////////////////////////////////

/**
 * @param branch_length An integer 
 * @param angle The angle of degree
 * @param t A Turtle object
 * @return A drawing symbolizing a tree branch
 */
void RecursiveTree(int branch_length, int angle, Turtle& t) {
  
  //add function defintions below
  
  
  
  //add function definitions above
  
}

int main(int argc, char** argv) {
  
  //add code below this line
  
  
  
  //add code above this line
  
  screen.exitonclick();
  return 0;
  
}