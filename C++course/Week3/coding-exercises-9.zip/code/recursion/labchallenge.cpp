#include <iostream>
using namespace std;

//add function definitions below this line



//add function definitions above this line

int main(int argc, char** argv) {
  cout << RecursivePower(stoi(argv[1]), stoi(argv[2])) << endl;
  return 0;
}
