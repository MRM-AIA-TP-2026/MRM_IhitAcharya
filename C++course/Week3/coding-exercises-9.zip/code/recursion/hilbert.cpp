////////// DO NOT EDIT HEADER! //////////
#include <iostream>                    //
#include "CTurtle.hpp"                 //
#include "CImg.h"                      //
using namespace cturtle;               //
using namespace std;                   //
/////////////////////////////////////////

/**
 * @param dist, integer 
 * @param rule, integer
 * @param angle, integer
 * @param depth, integer
 * @param t, Turtle
 * @return A drawing of the Hilbert Curve
 */
void Hilbert(int dist, int rule, int angle, int depth, Turtle& t) {
  
  //add function definitions below
  
  
  
  //add function definitions above
  
}

int main(int argc, char** argv) {
  
  //add code below this line
  
  TurtleScreen screen(400, 300);
  Turtle tina(screen);
  
  //add code above this line
  
  screen.exitonclick();
  return 0;
  
}