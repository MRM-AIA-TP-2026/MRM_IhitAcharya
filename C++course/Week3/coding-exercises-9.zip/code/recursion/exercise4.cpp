#include <iostream>
using namespace std;

//add function definitions below this line
string ReverseString(string x)
{
     string reversedStr = "";
    for (int i = x.length() - 1; i >= 0; i--) {
        reversedStr += x[i];
    }
    return reversedStr;
}



//add function definitions above this line

int main(int argc, char** argv) {
  cout << ReverseString(argv[1]) << endl;
  return 0;
}
