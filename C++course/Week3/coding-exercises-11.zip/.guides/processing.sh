#!/bin/bash
. /etc/profile.d/codio-xserver.sh
nohup /home/codio/processing/processing &> /dev/null &