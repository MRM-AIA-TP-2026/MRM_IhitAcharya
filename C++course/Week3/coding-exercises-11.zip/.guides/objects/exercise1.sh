cd code/objects
g++ exercise1.cpp -o exercise1
./exercise1 $*
