cd code/objects
g++ labchallenge.cpp -o labchallenge
./labchallenge $*
