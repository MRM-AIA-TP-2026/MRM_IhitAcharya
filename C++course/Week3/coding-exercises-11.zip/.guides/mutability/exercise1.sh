cd code/mutability
g++ exercise1.cpp -o exercise1
./exercise1 $*
