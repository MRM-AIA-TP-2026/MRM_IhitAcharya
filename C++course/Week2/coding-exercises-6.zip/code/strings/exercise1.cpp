#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  string my_string = (argv[1]);
  
  //add code below this line

char cf,cl;
cf = my_string[0];
cl = my_string[my_string.length() - 1];
cout << cf << " is the first character and " << cl << " is the last character";

  //add code above this line
  
  return 0;
  
}