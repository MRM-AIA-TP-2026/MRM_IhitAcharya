#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  string original = (argv[1]);
  string modified;
  char ch;
  
  //add code below this line
string temp = original;
for (int i=0;i<original.length();i++)
{ch = original[i];
  if (isupper(ch)>0)
  {original[i]='u';
  }
  else if (islower(ch)>0)
  original[i]='l';
  else
  original[i]='-';

}

for (char c:temp)
cout << c;
cout << '\n';
for (char c:original)
cout << c;

  //add code above this line
  
  return 0;
  
}