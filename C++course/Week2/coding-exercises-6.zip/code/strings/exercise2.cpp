#include <iostream>
using namespace std;

int main(int argc, char** argv) {
  
  string my_string = (argv[1]);
  
  //add code below this line
for (int i=0;i<my_string.length();i++)
cout << my_string << endl;


  //add code above this line
  
  return 0;
  
}