cd code/vectors
g++ exercise4.cpp -o exercise4
./exercise4 $1 $2 $3 $4
