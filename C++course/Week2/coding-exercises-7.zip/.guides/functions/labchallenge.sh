cd code/functions
g++ labchallenge.cpp -o labchallenge
./labchallenge $*
