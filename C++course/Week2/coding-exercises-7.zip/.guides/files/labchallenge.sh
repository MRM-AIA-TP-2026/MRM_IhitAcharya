cd code/files
g++ labchallenge.cpp -o labchallenge
./labchallenge $*
