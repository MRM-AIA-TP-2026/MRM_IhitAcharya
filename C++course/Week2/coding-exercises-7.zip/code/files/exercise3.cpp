#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {

////////// DO NOT EDIT! //////////
  string path = argv[1];        //
//////////////////////////////////  
  
  //add code below this line
string read;
vector<string> num(0);
ifstream file;
file.open(path);

  while (getline(file, read)) {
    stringstream ss(read);
    while (getline(ss, read)) {
      num.push_back(read);
    }
  }
  file.close();

  
for (int i = num.size()-1; i >= 0; i--) {
  cout << num.at(i) << endl;
}


  //add code above this line
  
  return 0;
  
}
