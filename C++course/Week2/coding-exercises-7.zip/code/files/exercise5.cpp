#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {

////////// DO NOT EDIT! //////////
  string path = argv[1];        //
//////////////////////////////////  
  
  //add code below this line
vector<string> line(0);
ifstream file;
string read;
file.open(path);


  while (getline(file, read)) {
    stringstream ss(read);
    while (getline(ss, read, ',')) {
      line.push_back(read);
    }
  }
  file.close();

string place;

for (int i = 6; i < line.size(); i+=4) {
  if (stoi(line.at(i)) < 0) {
    place += (line.at(i - 2) + ", ");
  }
}
  
place.pop_back();
place.pop_back();

  
cout << "The following cities are in the Southern Hemisphere: " << place << ".";





  //add code above this line
  
  return 0;
  
}
