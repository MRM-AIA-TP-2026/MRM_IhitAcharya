#include <iostream>
#include <fstream>
using namespace std;

int main() {
  
  //add code below this line



  //add code above this line
  
  return 0;
  
}
