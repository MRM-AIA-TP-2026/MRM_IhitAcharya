#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {

////////// DO NOT EDIT! //////////
  string path = argv[1];        //
//////////////////////////////////  
  
  //add code below this line


vector<string> num(0);
string read;
ifstream file;
file.open(path);
string old;


while (getline(file, read)) {
    stringstream ss(read);
    while (getline(ss, read, '\t')) {
    num.push_back(read);
    }
  }
  file.close();

int max = 0;
  
for (int i = 1; i < num.size(); i+=3) {
  if (stoi(num.at(i)) > max) {
    max = stoi(num.at(i));
    old = num.at(i - 1);
  }
}

cout << "The oldest person is " << old << ".";

  //add code above this line
  
  return 0;
  
}
