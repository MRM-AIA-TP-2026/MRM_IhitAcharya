#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {

////////// DO NOT EDIT! //////////
  string path = argv[1];        //
//////////////////////////////////  
  
  //add code below this line
vector<string> num(0);

ifstream file;
file.open(path);
string read;
  while (getline(file, read)) {
    stringstream ss(read);
    while (getline(ss, read, ',')) {
      num.push_back(read);
    }
  }
  file.close();


int avg1 = 0;
int avg2 = 0;
int avg3 = 0;
int avg4 = 0;
for (int i = 0; i < num.size(); i++) {
  if (i%4==0) {
    avg1 += stoi(num.at(i));
  }
  if (i%4==1) {
    avg2 += stoi(num.at(i));
  }
  if (i%4==2) {
    avg3 += stoi(num.at(i));
  }
  if (i%4==3) {
    avg4 += stoi(num.at(i));
  }
}
  
cout << avg1 / 3 << " " << avg2 / 3 << " " << avg3 / 3 << " " << avg4 / 3;


  //add code above this line
  
  return 0;
  
}
