#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {

////////// DO NOT EDIT! //////////
  string path = argv[1];        //
//////////////////////////////////  
  
  //add code below this line
string read,temp;
int lines=0,chars = 0;
ifstream file;
file.open(path);
while (getline(file,read))
{lines += 1;
for (char ch:read)
{chars +=1;}}
cout << lines << " line(s)" << '\n';
cout << chars << " character(s)";


  
  //add code above this line
  
  return 0;
  
}