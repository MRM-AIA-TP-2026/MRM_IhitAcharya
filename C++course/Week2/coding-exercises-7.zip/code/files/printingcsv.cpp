#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

int main() {
  
  //add code below this line



  //add code above this line
  
  return 0;
  
}
