cd code/strings
g++ exercise4.cpp -o exercise4
./exercise4 $1
