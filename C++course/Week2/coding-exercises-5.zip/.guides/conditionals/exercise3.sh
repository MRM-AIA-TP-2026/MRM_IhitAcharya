cd code/conditionals
g++ exercise3.cpp -o exercise3
./exercise3 $1
