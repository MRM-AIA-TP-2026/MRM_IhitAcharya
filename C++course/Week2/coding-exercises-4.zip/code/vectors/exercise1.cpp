#include <iostream>
using namespace std;

int main() {
  
  string oceans[] = {"Pacific", "Atlantic", "Indian", "Arctic", "Southern"};
  
  //add code below this line
for (auto i:oceans)
cout << i << endl;


  //add code above this line
  
  return 0;
  
}